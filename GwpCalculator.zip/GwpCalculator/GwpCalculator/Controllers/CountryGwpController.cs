﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CountryGalytix.ServiceLayer;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace GwpCalculator.Controllers
{

    [ApiController]
    public class CountryGwpController : ControllerBase
    {
        private ICalculateGwpAverage _calculateGwpAverage;
        public CountryGwpController(ICalculateGwpAverage calculateGwpAverage)
        {
            this._calculateGwpAverage = calculateGwpAverage;
        }

        [Route("server/api/gwp/avg")]
        [HttpPost]
        public async Task<ActionResult<IDictionary<string, double>>> Post([FromBody] JObject value)
        {
            var list = value["lob"].ToObject<List<string>>();
            var response =  await _calculateGwpAverage.FetchAverageGrowth(value.Value<string>("country"), list);
            return (Dictionary<string,double>)response;
        }

    }
}
