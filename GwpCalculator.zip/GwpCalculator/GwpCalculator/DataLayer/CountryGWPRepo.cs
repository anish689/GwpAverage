﻿using GwpCalculator.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountryGalytix.DataLayer
{
    class CountryGWPRepo : ICountryGWPRepo
    {
        private readonly IEnumerable<CountryGwpItem> _countryGwpItems = Enumerable.Empty<CountryGwpItem>();
        public  CountryGWPRepo(string path)
        {
            try
            {
                _countryGwpItems = GwpCsvParser.ParseCsv(path).ToArray();
            }
            catch (Exception)
            {
                // log 
                // I am not implementing proper exception handling considering it is test (not prod code) and due to the lack of time, sorry 
                throw;
            }
        }
#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
        public async Task<IEnumerable<CountryGwpItem> > FetchValuesForLob()
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously
        {
            return  _countryGwpItems.ToArray();
        }
    }
}
