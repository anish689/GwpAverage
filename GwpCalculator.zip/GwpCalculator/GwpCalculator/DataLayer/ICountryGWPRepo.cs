﻿using GwpCalculator.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CountryGalytix.DataLayer
{
    interface ICountryGWPRepo
    {
        public Task<IEnumerable<CountryGwpItem>> FetchValuesForLob();
    }
}
