﻿using CountryGalytix.DataLayer;
using GwpCalculator.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountryGalytix.ServiceLayer
{
    class CalculateGwpAverage : ICalculateGwpAverage
    {
        private ICountryGWPRepo _gwpRepo;
        public CalculateGwpAverage(ICountryGWPRepo gwpRepo)
        {
            this._gwpRepo = gwpRepo;
        }
        public async Task<IDictionary<string, double>> FetchAverageGrowth(string country, List<string> lob)

        {
            IEnumerable<CountryGwpItem> response = await _gwpRepo.FetchValuesForLob();
            var countryvalue = response.Where(x => x.Country == country).Select(y => y);
            var lineOfBusinesses = response.Where(x => x.Country == country).Select(x => x.LineOfBusiness);

            var list = new List<IDictionary<string, double>>();
            var lobAverage = new Dictionary<string, double>();
            foreach (var z in lob)
            {
                foreach (var y in countryvalue)
                {

                    if (y.LineOfBusiness == z)
                    {
                        double average = GetAverageGrowthRate(y);
                        lobAverage.Add(y.LineOfBusiness, average);
                        //list.Add(lobAverage);
                    }

                }

            }
            //list.Add(lobAverage);
            return lobAverage;
            //CountryGwpItem selectedCountry = _countryGwpItems.FirstOrDefault(c => c.Country == country && c.LineOfBusiness == lineOfBusiness);
        }

        public static double GetAverageGrowthRate(CountryGwpItem countryvalue)
        {

            var values = countryvalue.Gwp
                 .Where(gwp => gwp.Key >= 2008 && gwp.Key <= 2015)
                 .OrderBy(p => p.Key)
                 .Select(p => p.Value).ToArray();

            if (values.Length == 0) return 0;
            if (values.Length == 1) return 1;

            //double[] netAverage = new double[values.Length];
            //for (int i = 0; i <= values.Length; i++)
            //{
            //    netAverage[i] = (double)values[i];
            //}

            return (double)values.Average();
        }
    }
}
