﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CountryGalytix.ServiceLayer
{
    public interface ICalculateGwpAverage
    {
        public  Task<IDictionary<string, double>> FetchAverageGrowth(string country, List<string> lob);

    }
}
