﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GwpCalculator.Model
{
    public class CountryGwpItem
    {
        public string Country { get; set; }
        public string VariableId { get; set; }
        public string VariableName { get; set; }
        public string LineOfBusiness { get; set; }
        public Dictionary<int, decimal> Gwp { get; set; }
    }
}
